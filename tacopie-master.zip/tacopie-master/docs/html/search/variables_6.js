var searchData=
[
  ['wr_5fcallback',['wr_callback',['../structtacopie_1_1io__service_1_1tracked__socket.html#ae46fc6ee7102027316eceff64116ba9d',1,'tacopie::io_service::tracked_socket']]]
];
