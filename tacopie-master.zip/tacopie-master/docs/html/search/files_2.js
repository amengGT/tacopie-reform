var searchData=
[
  ['logger_2ehpp',['logger.hpp',['../logger_8hpp.html',1,'']]]
];
