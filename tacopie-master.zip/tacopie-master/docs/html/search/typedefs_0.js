var searchData=
[
  ['async_5fread_5fcallback_5ft',['async_read_callback_t',['../classtacopie_1_1tcp__client.html#acdf9dea8bac6c56f7b04ce38b9432322',1,'tacopie::tcp_client']]],
  ['async_5fwrite_5fcallback_5ft',['async_write_callback_t',['../classtacopie_1_1tcp__client.html#ad48b8c8dff8a77490eb2e3e802c82b97',1,'tacopie::tcp_client']]]
];
