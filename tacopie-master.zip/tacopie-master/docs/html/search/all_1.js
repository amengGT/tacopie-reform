var searchData=
[
  ['bind',['bind',['../classtacopie_1_1tcp__socket.html#a910a183d7c45483f1cdacd10a1896155',1,'tacopie::tcp_socket']]],
  ['buffer',['buffer',['../structtacopie_1_1tcp__client_1_1read__result.html#a50d22ea3a43d085d88d54bbf59a357dc',1,'tacopie::tcp_client::read_result::buffer()'],['../structtacopie_1_1tcp__client_1_1write__request.html#a4ee0c159b630c14f81d6b6d7d4b4e826',1,'tacopie::tcp_client::write_request::buffer()']]]
];
