var searchData=
[
  ['wait_5ffor_5fremoval',['wait_for_removal',['../classtacopie_1_1io__service.html#aa57db619baeaa6db0aeb22e67b895cd7',1,'tacopie::io_service']]],
  ['warn',['warn',['../classtacopie_1_1logger__iface.html#ab96d8f6bc2e2b514c7ceec4c856f8921',1,'tacopie::logger_iface::warn()'],['../classtacopie_1_1logger.html#aa4cd2ffc3f4b9d096a35c5c2aa8e0970',1,'tacopie::logger::warn()'],['../namespacetacopie.html#ac0a2f06f2f9fb6ded97b659d8573c25d',1,'tacopie::warn()']]]
];
