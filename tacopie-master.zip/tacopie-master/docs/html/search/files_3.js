var searchData=
[
  ['self_5fpipe_2ehpp',['self_pipe.hpp',['../self__pipe_8hpp.html',1,'']]]
];
