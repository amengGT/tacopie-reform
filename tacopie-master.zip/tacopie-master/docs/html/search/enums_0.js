var searchData=
[
  ['log_5flevel',['log_level',['../classtacopie_1_1logger.html#ae7dd235972bbf86a017fc39b3af80efe',1,'tacopie::logger']]]
];
