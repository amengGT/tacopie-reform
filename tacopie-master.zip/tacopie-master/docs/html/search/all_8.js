var searchData=
[
  ['notify',['notify',['../classtacopie_1_1self__pipe.html#ade9e0e3d19b8d4d22977935a578d508e',1,'tacopie::self_pipe']]]
];
