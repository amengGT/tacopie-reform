var searchData=
[
  ['server',['SERVER',['../classtacopie_1_1tcp__socket.html#ad8376e85df96ab9523f5d079ed7172aba3d27c95bfdbea691b250894d96852844',1,'tacopie::tcp_socket']]]
];
