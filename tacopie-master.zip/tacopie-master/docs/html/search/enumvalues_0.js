var searchData=
[
  ['client',['CLIENT',['../classtacopie_1_1tcp__socket.html#ad8376e85df96ab9523f5d079ed7172abaef10c650df47bffd6399e5e78da2a9b1',1,'tacopie::tcp_socket']]]
];
