var searchData=
[
  ['logger',['logger',['../classtacopie_1_1logger.html',1,'tacopie']]],
  ['logger_5fiface',['logger_iface',['../classtacopie_1_1logger__iface.html',1,'tacopie']]]
];
