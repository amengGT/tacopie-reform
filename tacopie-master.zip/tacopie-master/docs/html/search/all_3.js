var searchData=
[
  ['debug',['debug',['../classtacopie_1_1logger__iface.html#a156abb02ab852ea4033fc13f4902ee7a',1,'tacopie::logger_iface::debug()'],['../classtacopie_1_1logger.html#aff31bbc7d3fdbbe60a2331fe24ec76ff',1,'tacopie::logger::debug()']]],
  ['disconnect',['disconnect',['../classtacopie_1_1tcp__client.html#a7562e0bfa24912595d6f695f848b9e51',1,'tacopie::tcp_client']]],
  ['disconnection_5fhandler_5ft',['disconnection_handler_t',['../classtacopie_1_1tcp__client.html#aca5df52e5ee6fa673cf212532ada1453',1,'tacopie::tcp_client']]]
];
